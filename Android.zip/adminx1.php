<?php
require_once __DIR__ . '/config.php';
session_start();
if (empty($_SESSION['lzr_admin'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
        $hash = LZR_ADMIN_PASS_HASH;
        if (LZR_ADMIN_USER !== 'change_this_admin' && $hash !== '' &&
            hash_equals(LZR_ADMIN_USER, (string)$_POST['username']) &&
            password_verify((string)$_POST['password'], $hash)) {
            session_regenerate_id(true);
            $_SESSION['lzr_admin'] = true;
            header('Location: adminx1.php'); exit;
        }
        $error = 'Login failed. Configure admin credentials in config.php.';
    }
    ?><!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>LZR Admin</title>
    <style>body{font:16px Arial;background:#101522;color:#eef2ff;display:grid;place-items:center;min-height:100vh;margin:0}.box{background:#1b2435;padding:28px;border-radius:16px;width:min(360px,85vw)}input,button{box-sizing:border-box;width:100%;padding:12px;margin:8px 0;border-radius:8px;border:1px solid #43506a;background:#111827;color:white}button{background:#647cff;border:0;font-weight:bold}.muted{color:#b8c3d9;font-size:13px}.err{color:#ff9c9c}</style></head><body><form class="box" method="post"><h2>LZR Admin</h2><p class="muted">Set admin credentials in config.php before use.</p><?php if(isset($error)) echo '<p class="err">'.htmlspecialchars($error).'</p>'; ?><input name="username" placeholder="Username" required><input name="password" type="password" placeholder="Password" required><button>Sign in</button></form></body></html><?php
    exit;
}
if (isset($_GET['logout'])) { session_destroy(); header('Location: adminx1.php'); exit; }
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
        $message = 'Session expired. Refresh and try again.';
    } else {
        $licenses = lzr_read_licenses();
        if ($_POST['action'] === 'create') {
            $days = max(0, min(36500, (int)($_POST['days'] ?? 30)));
            $key = 'LZR-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(4)));
            $hash = hash('sha256', strtoupper($key));
            $licenses[$hash] = ['active'=>true,'expiresAt'=>$days === 0 ? 0 : time()+($days*86400),'deviceId'=>'','createdAt'=>time(),'label'=>substr(trim((string)($_POST['label'] ?? '')),0,80)];
            if (lzr_write_licenses($licenses)) $message = 'NEW KEY (copy now): ' . $key;
            else $message = 'Could not save. Check data/ folder permissions and PHP OpenSSL.';
        } elseif ($_POST['action'] === 'toggle' && isset($_POST['hash']) && isset($licenses[$_POST['hash']])) {
            $licenses[$_POST['hash']]['active'] = empty($licenses[$_POST['hash']]['active']);
            lzr_write_licenses($licenses);
            $message = 'License status updated.';
        } elseif ($_POST['action'] === 'unbind' && isset($_POST['hash']) && isset($licenses[$_POST['hash']])) {
            $licenses[$_POST['hash']]['deviceId'] = '';
            unset($licenses[$_POST['hash']]['boundAt']);
            lzr_write_licenses($licenses);
            $message = 'Device binding cleared.';
        }
    }
}
$_SESSION['csrf'] = bin2hex(random_bytes(16));
$licenses = lzr_read_licenses();
?><!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>LZR Admin</title><style>
body{font:15px Arial;background:#101522;color:#eef2ff;margin:0;padding:20px}.wrap{max-width:900px;margin:auto}.card{background:#1b2435;padding:20px;border-radius:14px;margin:14px 0}input,button{padding:10px;border-radius:8px;border:1px solid #43506a;background:#111827;color:white}button{cursor:pointer;background:#647cff;border:0}.danger{background:#b74455}.muted{color:#b8c3d9}.notice{background:#243c37;padding:12px;border-radius:8px;overflow-wrap:anywhere}.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:10px;border-bottom:1px solid #344056;font-size:13px} .tablewrap{overflow-x:auto}</style></head><body><div class="wrap"><div class="row"><h1>LZR Admin</h1><a style="margin-left:auto;color:#b8c3d9" href="?logout=1">Logout</a></div>
<?php if($message!=='') echo '<div class="notice">'.htmlspecialchars($message).'</div>'; ?>
<div class="card"><h2>Create license</h2><form method="post" class="row"><input type="hidden" name="csrf" value="<?=htmlspecialchars($_SESSION['csrf'])?>"><input type="hidden" name="action" value="create"><input name="label" placeholder="Label (optional)"><input type="number" name="days" value="30" min="0" max="36500"><span class="muted">days (0 = lifetime)</span><button>Create key</button></form></div>
<div class="card"><h2>Licenses (<?=count($licenses)?>)</h2><p class="muted">Only a SHA-256 key hash is stored. Device IDs are shown only as bound/unbound.</p><div class="tablewrap"><table><tr><th>Label</th><th>Status</th><th>Expiry</th><th>Device</th><th>Actions</th></tr>
<?php foreach($licenses as $hash=>$l): ?><tr><td><?=htmlspecialchars($l['label']??'')?></td><td><?=!empty($l['active'])?'Active':'Disabled'?></td><td><?php $ex=(int)($l['expiresAt']??0); echo $ex===0?'Lifetime':gmdate('Y-m-d H:i',$ex).' UTC'; ?></td><td><?=!empty($l['deviceId'])?'Bound':'Unbound'?></td><td><form method="post" class="row"><input type="hidden" name="csrf" value="<?=htmlspecialchars($_SESSION['csrf'])?>"><input type="hidden" name="hash" value="<?=htmlspecialchars($hash)?>"><button name="action" value="toggle" class="danger"><?=!empty($l['active'])?'Disable':'Enable'?></button><button name="action" value="unbind">Unbind</button></form></td></tr><?php endforeach; ?>
</table></div></div><p class="muted">Keep config.php private and back up encrypted data/licenses.enc securely.</p></div></body></html>
