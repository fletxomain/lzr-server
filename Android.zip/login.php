<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    lzr_json(405, ['success'=>false, 'message'=>'GET required']);
}

$key = isset($_GET['key']) ? trim((string)$_GET['key']) : '';
$device = isset($_GET['device_id']) ? trim((string)$_GET['device_id']) : '';

if ($key === '' || $device === '' || strlen($key) > 200 || strlen($device) > 200) {
    lzr_json(400, ['success'=>false, 'message'=>'Key and device ID required']);
}

$licenses = lzr_read_licenses();
$hash = hash('sha256', strtoupper($key));

if (!isset($licenses[$hash])) {
    lzr_json(200, ['success'=>false, 'message'=>'Invalid license key']);
}

$license = $licenses[$hash];
if (empty($license['active'])) {
    lzr_json(200, ['success'=>false, 'message'=>'License disabled']);
}

$expiry = isset($license['expiresAt']) ? (int)$license['expiresAt'] : 0;
if ($expiry > 0 && time() >= $expiry) {
    lzr_json(200, ['success'=>false, 'message'=>'License expired']);
}

$bound = isset($license['deviceId']) ? (string)$license['deviceId'] : '';
if ($bound !== '' && !hash_equals($bound, $device)) {
    lzr_json(200, ['success'=>false, 'message'=>'License is already bound to another device']);
}

if ($bound === '') {
    $licenses[$hash]['deviceId'] = $device;
    $licenses[$hash]['boundAt'] = time();
    if (!lzr_write_licenses($licenses)) {
        lzr_json(500, ['success'=>false, 'message'=>'Could not save device binding']);
    }
}

lzr_json(200, ['success'=>true, 'message'=>'Login successful']);
