<?php
// LZR server configuration. Change these before deployment.
define('LZR_ADMIN_USER', 'LZR');
define('LZR_ADMIN_PASS_HASH', '$2y$12$IQpAmhK6JkEdE6kjn1KqWeMfRRg3Xqu85KN2bU0p77p8SrJafBgiG'); // Demo password; change before production.
define('LZR_DATA_FILE', __DIR__ . '/data/licenses.enc');
define('LZR_SECRET', 'fletxo_pjnNZffcBqy2lG0AcCk9FqTJ-1WqHzoXC6KzEjIXwSqYhXXz');
define('LZR_MAX_BODY_BYTES', 4096);
date_default_timezone_set('UTC');

function lzr_secret_key() {
    return hash('sha256', LZR_SECRET, true);
}
function lzr_read_licenses() {
    if (!is_file(LZR_DATA_FILE)) return [];
    $raw = file_get_contents(LZR_DATA_FILE);
    if ($raw === false || strlen($raw) < 29) return [];
    $iv = substr($raw, 0, 12);
    $tag = substr($raw, 12, 16);
    $cipher = substr($raw, 28);
    $json = openssl_decrypt($cipher, 'aes-256-gcm', lzr_secret_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($json === false) return [];
    $data = json_decode($json, true);
    return is_array($data) ? $data : [];
}
function lzr_write_licenses($data) {
    $json = json_encode($data, JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    $iv = random_bytes(12);
    $tag = '';
    $cipher = openssl_encrypt($json, 'aes-256-gcm', lzr_secret_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($cipher === false) return false;
    $tmp = LZR_DATA_FILE . '.tmp';
    if (file_put_contents($tmp, $iv . $tag . $cipher, LOCK_EX) === false) return false;
    return rename($tmp, LZR_DATA_FILE);
}
function lzr_json($status, $body) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($body, JSON_UNESCAPED_SLASHES);
    exit;
}
